//Virtual Memory Simulator by Daniel McDonough 2/19/18

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SIZE 64 //given memory size

// Given memory array
unsigned char memory[SIZE];

/*
typedef struct{
int pagenum; //pagenumber
int offset; //the offset
}virtual_mem;


//transistion look aside buffer
typedef struct{
int pagenum; //given page number from virtual mem
int framenum; //value corresponding to given pagenum
}TLB;

//struct of the page table
typedef struct{
int valid; //valid bit
int dirty; //dirty bit
int PID; //process id
int pagenum; //page number
}page_table;


//struct of physical memory
typedef struct{
int frame_num;//frame number mapped to the page table 
int offset;//offset mapping to memory (the array) given by virtual mem
int value;//value stored
}physical_mem;
*/


// PID list
int pid_array[4];

// Free list
int free_list[4];

// write list
int write_list[4];

//checks if argument 2 is a valid instruction
int valid_instruction(char* argv[]){
//printf("%s\n",argv[0]);
if(argv[0] == "map"){
return 0;
}
if(argv[0] == "load"){
return 1;
}
if(argv[0] == "save"){

return 2; 
}
return 3; //bad instruction


}

//From page number get start index
int get_address(int pagenum){
    if (pagenum == 0){
        return 0;
    }
    else if (pagenum == 1){
        return 16;
    }
    else if (pagenum == 2){
        return 32;
    }
    else{
        return 48;
    }
}


//size 64 with 4 pages then split page num each 16 indeces
int get_page(int virtual_address){
    if (virtual_address < 16){
        return 0;
    }
    else if (virtual_address < 32){
        return 1;
    }
    else if (virtual_address < 48){
        return 2;
    }
    else{
        return 3;
    }
}

// Reads integer from memory
int read_mem(int start){
    int read_val;
    char buffer[4];
    for(int i = 0; i < 3; i++){
        if(memory[start + i] != '*')
            buffer[i] = memory[start + i];
        else{
            buffer[i] = '\0';
            break;
        }
    }

    sscanf(buffer, "%d", &read_val);
    return read_val;
}

//int into physical memory, start is the physical address we want to write to
int writeIntoMem(int start_address, char* value){
int i;    
for(int i = start_address; i < 16 + start_address; i++){
        if(value[i - start_address] != 0){
            memory[i] = value[i - start_address];
	}
        else{
            break;
	}
    }

    return (i - start_address); // Number of bytes written
}


// Translate page table, return physical address
int translate_ptable(int pid, int v_addr){
    int pt_start = pid_array[pid]; // Get address of page table for that process
    char int_buf[10] = ""; // Holds the string that makes up an address index
    int cur_v_addr = 0;
    int phys_addr = -1;
    int diff = -1;	

    //Get physical address
    int cur_addr = pt_start;
    for (int i = 0; i < 16; i++){ // Only look up to end of page table virtual page
    
        if (memory[cur_addr] == ','){//(strncmp(&memory[cur_addr], ",", sizeof(memory[cur_addr]))) // End of virtual address for PTE
        
            cur_v_addr = atoi(int_buf);int_buf[0] = '\0';
            memset(&int_buf[0], 0, sizeof(int_buf));
        }
        else if (memory[cur_addr] == '.'){//(strncmp(&memory[cur_addr], ".", sizeof(memory[cur_addr]))) // End of PTE
        
	    if(diff == -1){
		diff = atoi(int_buf) - cur_v_addr;
}

            if (cur_v_addr == v_addr){
            
                phys_addr = atoi(int_buf);
            }
            memset(&int_buf[0], 0, sizeof(int_buf));
	    
        }
        else{ // Reading address
	    if(isdigit(memory[cur_addr])){
                strncat(int_buf, &memory[cur_addr], 1);
}
        }
        cur_addr++;
    }
    if(phys_addr == -1){
	phys_addr = v_addr + diff;
}
    return phys_addr; // Return physical address, -1 if address not found
}

// Allocates page table entry into virtual page
int create_ptable(int pid){
    int been_allocated = -1;
    for(int i = 0; i < 4; i++){
        if (free_list[i] == -1){
            free_list[i] = 0;
            pid_array[pid] = get_address(i); // Put physical address into pid register
            been_allocated = 1;
            printf("Put page table for PID %d into physical frame %d\n", pid, i);
            break;
        }
    }

    if (been_allocated == -1){
        printf("ERROR: No free space, Memory is full!\n");
    }
}

// Allocates physical page
int map(int pid, int v_addr, int value){
    int page_table = pid_array[pid];
    int been_allocated = -1;
    char full_str[16] = "";
    char buffer[10];

    if (page_table == -1)
    {
        create_ptable(pid);
    }

    for(int i = 0; i < 4; i++){
        if (free_list[i] == -1){
            free_list[i] = 0;
            write_list[i] = value; // Set permissions
            been_allocated = 1;

            int write_addr = pid_array[pid];
            for(int j = 0; j < 16; i++){
                if (memory[write_addr] == '*'){ // Write entry to ptable
                
                    sprintf(buffer, "%d", v_addr);
                    strcat(full_str, buffer);
                    strcat(full_str, ",");
                    sprintf(buffer, "%d", get_address(i) + v_addr);
                    strcat(full_str, buffer);
                    strcat(full_str, ".");
                    write_addr += writeIntoMem(write_addr, full_str);
                    break;
                }
                write_addr++;
            }

            printf("Mapped virtual address %d (page %d) into physical frame %d\n", v_addr, get_page(v_addr), i);
            break;
        }
    }

    if (been_allocated == -1){
        printf("ERROR: No free space, Memory is full!\n");
    }

    return 0; // Success
}
int load(int pid, int v_addr){
    int phys_addr = translate_ptable(pid, v_addr);
    printf("The value %d is virtual address %d (physical address %d)\n", read_mem(phys_addr), v_addr, phys_addr);

    return 0; // Success
}
int store(int pid, int v_addr, int value){
    int phys_addr = translate_ptable(pid, v_addr);
    char buffer[10] = "";

    if (write_list[get_page(phys_addr)] == 1){
        sprintf(buffer, "%d", value);
        writeIntoMem(phys_addr, buffer);
        printf("Stored value %d at virtual address %d (physical address %d)\n", value, v_addr, phys_addr);
    }
    else{
        printf("ERROR; writes are not allowed to this page\n");
    }

    return 0; // Success
}



// The main function
int main(int argc, char *argv[]){

    int pid = 0; //the process id [0,3]
    int instType = 0; // Instruction type Map = 0 Load = 1 Save =2 Error =3
    int v_addr = 0; // Virtual address
    int value = 0; // Value
    int is_end = 0; // EOF flag

    char buffer[20]; // Holds stdin buffer
    char cmd_seq[20]; // The command sequence read from stdin
    char* cmd_array[4]; // Holds the commands read from file
    char* token;

    // Initialize ptable, free and write lists
    for (int i = 0; i < 4; i++){
        pid_array[i] = 0;
        free_list[i] = 0;
        write_list[i] = 0;
    }

    //Initialiaze physical memory
    for (int i = 0; i < SIZE; i++){
        memory[i] = '*';
    }

    while (is_end != 1){

        printf("Instruction?: ");
        // Recieve stdin
        if (argc <= 1){
            // Read sequence from file
            if (fgets(buffer, sizeof(buffer), stdin) == NULL){
                is_end = 1;
                printf("End of File. Exiting\n");
                break;
            }
            buffer[strcspn(buffer, "\n")] = 0; //Remove newline
            strncpy(cmd_seq, &buffer[0], sizeof(cmd_seq));
            printf("%s\n", cmd_seq);

            // Parse sequence
            token = strtok(cmd_seq, ",");
            int i = 0;
            while (token != NULL){
                if (i >= 4) {
                    printf("ERROR: Too many input arguments!\n");
                    break;
                }
                cmd_array[i] = token;
                i++;
                token = strtok(NULL, ",");
            }
		if(i <=3){
printf("ERROR: Too few input arguments!\n");
                    break;
}

            // Put sequence into variables
            pid = atoi(cmd_array[0]);
	    instType = valid_instruction(&cmd_array[1]);
            
            v_addr = atoi(cmd_array[2]);
            value = atoi(cmd_array[3]);
		if(pid > 3 || instType == 3 || v_addr > 63 || value > 255){
printf("ERROR: invalid arguments!\n");
break;
}
        }

        if (is_end == 1) break; // Break if EOF

        printf("Parsed command: %d, %d, %d, %d\n", pid, instType, v_addr, value);

        if (instType == 1)
        {
            map(pid, v_addr, value);
        }
        else if (instType == 2)
        {
            store(pid, v_addr, value);
        }
        else if (instType == 3)
        {
            load(pid, v_addr);
        }
    }

    return 0;
}
void print_error(){
printf("\nHold on there space cowboy...\n");
            printf("Please use:\n\t ./vmSim process_id,instruction_type,virtual_address,value\n");
            printf("Where:\n");
		printf("\tprocess_id is [0,3]:\n");
		printf("\tinstruction_type: map,load,save\n");
		printf("\tvirtual_address: [0,63]\n");
		printf("\tvalue: [0,255]\n");
            exit(1);

}



//copied leftovers from my project 3

/*
//THE ALMIGHTY MAIN FUNCTION
int main(int argc, char *argv[]) {
 char* token;
 char* cmd_array[4]; // Holds the commands read from file
int End_of_File = 0; //EOF flag

if(argc > 2){
//reading from file (ie automatic control)
return(0);
}
else if(argc <= 1 ){
//no arg input (ie manual)
return(0);
}
else{
//1 arg input (ie manual and once at start up)
   //parse the one argument
	char arg1[5] = "0";
char arg2[10] = "map";
char arg3[10] = "63";
char arg4[10] = "255";
          //sscanf(argv[1], "%[^,\n],%[^,\n],%[^,\n],%[^,\n]", arg1,arg2,arg3,arg4);
	  printf("da");

//check uppper bounds
        if (atoi(cmd_array[1]) > 3 ||valid_instruction(&cmd_array[2])|| atoi(cmd_array[3]) > 63 || atoi(cmd_array[4]) > 255) {
           print_error();
        }
//printf("Success\n\n");

//check lower bounds
        if (atoi(cmd_array[1]) < 0 || valid_instruction(&cmd_array[2]) || atoi(cmd_array[3]) < 0 || atoi(cmd_array[4]) < 0) {
              print_error();
        }


        int processid = atoi(cmd_array[1]); //# of users
        char* instruction_type = cmd_array[2]; //mean loop count
        int virtual_address = atoi(cmd_array[3]); //mean arrival time
        int value = atoi(cmd_array[4]); //mean stay


        printf("\nValid Input recognized!\n");
        printf("Processid:%d\n", processid);
        printf("Instruction:%s\n", instruction_type);
        printf("Virtual_address:%d\n", virtual_address);
        printf("Value:%d\n\n", value);
//VALID INPUT!
	printf("Instruction?:\n");


    } 



    return 0;
}
*/

